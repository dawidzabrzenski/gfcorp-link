function Clients() {
  return <div>Clients</div>;
}

export default Clients;
